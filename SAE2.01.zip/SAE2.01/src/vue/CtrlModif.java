package vue;

import java.util.Optional;

import Controleur.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class CtrlModif {
	@FXML private TextField montantField;
    @FXML private TextField idField;
    @FXML private TextField prenomField;
    @FXML private DatePicker datePaiementPicker;
    @FXML private Button bnAnnuler;
    @FXML private TextField nomField;
    @FXML private Button bnEnregistrer;
    @FXML private Button bnSuppMembre;
    
    @FXML void clicAnnuler() {
    	Main.closeModif();
    }
    
    // clic sur bouton Supprimer
    @FXML void clicSupprimer(ActionEvent event) {
    	Alert alert = new Alert(
				AlertType.CONFIRMATION,
				"Voulez-vous vraiment supprimer cet élève ?",
				ButtonType.YES,
				ButtonType.NO
		);
		alert.setTitle("Confirmation de suppression");
		Optional<ButtonType> reponse =alert.showAndWait();
		if (reponse.get().equals(ButtonType.YES)) {
			
		}
    }
    
    @FXML void clicEnregistrer() {
    	
    	Main.closeModif();
    }
    
}
